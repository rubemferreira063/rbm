<?php
// Ajuste conforme o nome da pasta do projeto
define('APP_URL', '/bolao');
