      </main>
        </div>
    </div>

   <footer class="text-center py-3 bg-black text-white mt-auto">
  <div class="container">
    <p class="mb-0">⚫⚪ Aqui é Galo! ⚫⚪</p>
    <small class="text-warning">Clube Atlético Mineiro - O time do povo</small>
  </div>
</footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
