<?php
$host = "localhost";
$dbname = "bolao";
$user = "root";   // padrão do Laragon
$pass = "";       // senha vazia por padrão

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // echo "Conexão realizada com sucesso!";
} catch (Exception $e) {
    die("Erro ao conectar ao banco: " . $e->getMessage());
}
?>
