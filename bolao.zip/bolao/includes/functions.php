<?php
function calcularPontuacao($palpite1, $palpite2, $gol1, $gol2, $time1, $time2) {
    $pontos = 0;

    // Se ainda não há resultado, não pontua
    if ($gol1 === null || $gol2 === null) {
        return 0;
    }

    // Placar exato
    if ($palpite1 == $gol1 && $palpite2 == $gol2) {
        $pontos += 5;
    }
    // Acertou diferença de gols (ex.: 2x1 e 3x2 -> mesma diferença)
    elseif (($palpite1 - $palpite2) == ($gol1 - $gol2)) {
        $pontos += 3;
    }
    // Acertou vencedor ou empate
    elseif (($palpite1 > $palpite2 && $gol1 > $gol2) || 
            ($palpite1 < $palpite2 && $gol1 < $gol2) || 
            ($palpite1 == $palpite2 && $gol1 == $gol2)) {
        $pontos += 2;
    }

    // Gols acertados individualmente
    if ($palpite1 == $gol1) $pontos += 1;
    if ($palpite2 == $gol2) $pontos += 1;

    // Bônus se for jogo do Galo e placar exato
    if (($time1 === "Atlético MG" || $time2 === "Atlético MG") && 
        $palpite1 == $gol1 && $palpite2 == $gol2) {
        $pontos += 2;
    }

    return $pontos;
}

// Função dos pontos
function exibirPontuacaoBadge($pontos) {
    if ($pontos >= 5) {
        return '<span class="badge bg-success">'.$pontos.' pts</span>';
    } elseif ($pontos >= 3) {
        return '<span class="badge bg-warning text-dark">'.$pontos.' pts</span>';
    } elseif ($pontos >= 1) {
        return '<span class="badge bg-info text-dark">'.$pontos.' pt</span>';
    } else {
        return '<span class="badge bg-secondary">0</span>';
    }
}
?>
