<?php
function escudo($time) {
    $arquivo = "../assets/escudos/" . $time . ".png";
    if (file_exists($arquivo)) {
        return "<img src='$arquivo' width='28' class='me-1'>";
    }
    return "";
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Bolão do Galo</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

    <link rel="stylesheet" href="../assets/css/style.css?v=1.0">
</head>
<body>
    <div class="d-flex flex-column min-vh-100">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 d-none d-md-block bg-black sidebar">
                <div class="position-sticky pt-3">
                    <h5 class="text-warning text-center mb-3">
                        <i class="bi bi-shield-fill"></i> Bolão do Galo
                    </h5>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link text-warning" href="../pages/participantes.php">
                                <i class="bi bi-people-fill"></i> Participantes
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-warning" href="../pages/rodadas.php">
                                <i class="bi bi-calendar-event"></i> Rodadas
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-warning" href="../pages/jogos.php">
                                <i class="bi bi-controller"></i> Jogos
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-warning" href="../pages/palpites.php">
                                <i class="bi bi-pencil-square"></i> Palpites
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-warning" href="../pages/resultados.php">
                                <i class="bi bi-flag"></i> Resultados
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-warning" href="../pages/classificacao.php">
                                <i class="bi bi-trophy-fill"></i> Classificação
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-warning" href="../pages/relatorio_participante.php">
                                <i class="bi bi-person-lines-fill"></i> Relatório Participante
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-warning" href="../pages/relatorio_geral.php">
                                <i class="bi bi-bar-chart-line"></i> Relatório Geral
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Conteúdo principal -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 flex-grow-1">