<?php
include "../includes/db.php";
include "../includes/header.php";
include "../includes/functions.php"; // calcularPontuacao e exibirPontuacaoBadge

$alert = "";

// Participantes para seleção
$participantes = $pdo->query("SELECT * FROM participantes ORDER BY nome ASC")->fetchAll(PDO::FETCH_ASSOC);

$participante_id = $_GET['participante_id'] ?? null;
$dados = [];

if ($participante_id) {
    $stmt = $pdo->prepare("SELECT pa.*, j.time1, j.time2, j.gol1, j.gol2, j.data, r.numero AS rodada_numero
                           FROM palpites pa
                           JOIN jogos j ON pa.jogo_id = j.id
                           JOIN rodadas r ON j.rodada_id = r.id
                           WHERE pa.participante_id=?
                           ORDER BY j.data ASC");
    $stmt->execute([$participante_id]);
    $dados = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<div class="container">
    <!-- Seleção de participante -->
    <div class="card mb-4 border-dark">
        <div class="card-header bg-black text-warning">
            <i class="bi bi-person-lines-fill"></i> Relatório por Participante
        </div>
        <div class="card-body">
            <form method="GET" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>" class="row g-3">
                <div class="col-md-8">
                    <label class="form-label">Participante</label>
                    <select name="participante_id" class="form-select" required>
                        <option value="">Selecione...</option>
                        <?php foreach ($participantes as $p): ?>
                            <option value="<?= $p['id'] ?>" <?= ($participante_id==$p['id'] ? "selected" : "") ?>>
                                <?= htmlspecialchars($p['nome']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-warning text-dark fw-bold mt-4">
                        <i class="bi bi-search"></i> Gerar Relatório
                    </button>
                </div>
            </form>
        </div>
    </div>

    <?php if ($participante_id && !empty($dados)): ?>
        <div class="card border-dark">
            <div class="card-header bg-black text-warning">
                <i class="bi bi-clipboard-data"></i> Palpites e Resultados
            </div>
            <div class="card-body">
                <table class="table table-striped align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>Rodada</th>
                            <th>Jogo</th>
                            <th>Data</th>
                            <th>Palpite</th>
                            <th>Resultado</th>
                            <th>Pontos</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $totalPontos = 0; ?>
                        <?php foreach ($dados as $d): ?>
                            <?php
                                $pontos = calcularPontuacao($d['palpite1'], $d['palpite2'], $d['gol1'], $d['gol2'], $d['time1'], $d['time2']);
                                $totalPontos += $pontos;
                            ?>
                            <tr>
                                <td>Rodada <?= htmlspecialchars($d['rodada_numero']) ?></td>
                                <td><?= htmlspecialchars($d['time1']) ?> x <?= htmlspecialchars($d['time2']) ?></td>
                                <td><?= date('d/m/Y H:i', strtotime($d['data'])) ?></td>
                                <td><?= $d['palpite1']." x ".$d['palpite2'] ?></td>
                                <td><?= ($d['gol1'] !== null && $d['gol2'] !== null) ? $d['gol1']." x ".$d['gol2'] : "-" ?></td>
                                <td><?= exibirPontuacaoBadge($pontos) ?></td>
                            </tr>
                        <?php endforeach; ?>
                        <tr class="table-dark">
                            <td colspan="5" class="text-end fw-bold">Total de Pontos</td>
                            <td><?= exibirPontuacaoBadge($totalPontos) ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    <?php elseif ($participante_id): ?>
        <div class="alert alert-info"><i class="bi bi-info-circle"></i> Nenhum palpite encontrado para este participante.</div>
    <?php endif; ?>
</div>

<?php include "../includes/footer.php"; ?>