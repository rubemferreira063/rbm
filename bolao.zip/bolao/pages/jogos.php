<?php
include "../includes/db.php";
include "../includes/header.php";

$alert = "";

// Adicionar jogo
if (isset($_POST['add'])) {
    $rodada_id = $_POST['rodada_id'] ?? null;
    $time1 = trim($_POST['time1'] ?? "");
    $time2 = trim($_POST['time2'] ?? "");
    $data = $_POST['data'] ?? null;

    if ($rodada_id && $time1 && $time2 && $data) {
        $stmt = $pdo->prepare("INSERT INTO jogos (rodada_id, time1, time2, data) VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$rodada_id, $time1, $time2, $data])) {
            $alert = '<div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="bi bi-check-circle"></i> Jogo cadastrado com sucesso!
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                      </div>';
        } else {
            $alert = '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="bi bi-x-circle"></i> Erro ao cadastrar jogo.
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                      </div>';
        }
    } else {
        $alert = '<div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle"></i> Preencha todos os campos.
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                  </div>';
    }
}

// Editar jogo
if (isset($_POST['edit'])) {
    $id = $_POST['id'] ?? null;
    $rodada_id = $_POST['rodada_id'] ?? null;
    $time1 = trim($_POST['time1'] ?? "");
    $time2 = trim($_POST['time2'] ?? "");
    $data = $_POST['data'] ?? null;
    $gol1 = ($_POST['gol1'] !== "" ? $_POST['gol1'] : null);
    $gol2 = ($_POST['gol2'] !== "" ? $_POST['gol2'] : null);

    if ($id && $rodada_id && $time1 && $time2 && $data) {
        $stmt = $pdo->prepare("UPDATE jogos SET rodada_id=?, time1=?, time2=?, data=?, gol1=?, gol2=? WHERE id=?");
        if ($stmt->execute([$rodada_id, $time1, $time2, $data, $gol1, $gol2, $id])) {
            $alert = '<div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <i class="bi bi-pencil-square"></i> Jogo atualizado com sucesso!
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                      </div>';
        } else {
            $alert = '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="bi bi-x-circle"></i> Erro ao atualizar jogo.
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                      </div>';
        }
    } else {
        $alert = '<div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle"></i> Preencha todos os campos.
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                  </div>';
    }
}

// Excluir jogo
if (isset($_POST['delete'])) {
    $id = $_POST['id'] ?? null;
    if ($id) {
        $stmt = $pdo->prepare("DELETE FROM jogos WHERE id=?");
        if ($stmt->execute([$id])) {
            $alert = '<div class="alert alert-dark alert-dismissible fade show" role="alert">
                        <i class="bi bi-trash"></i> Jogo excluído com sucesso!
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                      </div>';
        } else {
            $alert = '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="bi bi-x-circle"></i> Erro ao excluir jogo.
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                      </div>';
        }
    }
}

// Busca
$search = $_GET['search'] ?? "";
$query = "SELECT j.*, r.numero AS rodada_numero 
          FROM jogos j 
          JOIN rodadas r ON j.rodada_id = r.id
          WHERE r.numero LIKE ? OR j.time1 LIKE ? OR j.time2 LIKE ?
          ORDER BY j.data ASC";
$stmt = $pdo->prepare($query);
$stmt->execute(["%$search%", "%$search%", "%$search%"]);
$jogos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Rodadas
$rodadas = $pdo->query("SELECT * FROM rodadas ORDER BY numero ASC")->fetchAll(PDO::FETCH_ASSOC);

// Times para autocomplete
$times = $pdo->query("SELECT nome FROM times ORDER BY nome ASC")->fetchAll(PDO::FETCH_COLUMN);
?>

<div class="container">
    <?= $alert ?>

    <!-- AUTOCOMPLETE -->
    <datalist id="listaTimes">
        <?php foreach ($times as $t): ?>
            <option value="<?= htmlspecialchars($t) ?>"></option>
        <?php endforeach; ?>
    </datalist>

    <!-- Formulário de cadastro -->
    <div class="card mb-4 border-dark">
        <div class="card-header bg-black text-warning">
            <i class="bi bi-plus-circle"></i> Adicionar Jogo
        </div>
        <div class="card-body">
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Rodada</label>
                    <select name="rodada_id" class="form-select" required>
                        <option value="">Selecione...</option>
                        <?php foreach ($rodadas as $r): ?>
                            <option value="<?= $r['id'] ?>">Rodada <?= $r['numero'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Time 1</label>
                    <input type="text" name="time1" class="form-control" list="listaTimes" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Time 2</label>
                    <input type="text" name="time2" class="form-control" list="listaTimes" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Data do Jogo</label>
                    <input type="datetime-local" name="data" class="form-control" required>
                </div>

                <button type="submit" name="add" class="btn btn-dark">
                    <i class="bi bi-check-circle"></i> Cadastrar
                </button>
            </form>
        </div>
    </div>

    <!-- Busca -->
    <form class="d-flex mb-3" method="GET">
        <input class="form-control me-2" type="search" name="search" placeholder="Buscar por rodada ou time..." value="<?= htmlspecialchars($search) ?>">
        <button class="btn btn-warning text-dark fw-bold" type="submit"><i class="bi bi-search"></i> Buscar</button>
    </form>

    <!-- Lista de jogos -->
    <div class="card border-dark">
        <div class="card-header bg-black text-warning">
            <i class="bi bi-list"></i> Lista de Jogos
        </div>
        <div class="card-body">
            <table class="table table-striped align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Rodada</th>
                        <th>Time 1</th>
                        <th>Time 2</th>
                        <th>Data</th>
                        <th>Placar</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                                    </tbody>
            </table>
        </div>
    </div>
</div>

<!-- MODAIS DE EDIÇÃO/EXCLUSÃO -->

<?php foreach ($jogos as $j): ?>

    <!-- Modal Editar -->
    <div class="modal fade" id="editModal<?= (int)$j['id'] ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <form method="POST" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>" class="modal-content">

                <div class="modal-header bg-black text-warning">
                    <h5 class="modal-title"><i class="bi bi-pencil-square"></i> Editar Jogo</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">

                    <input type="hidden" name="id" value="<?= (int)$j['id'] ?>">

                    <div class="mb-3">
                        <label class="form-label">Rodada</label>
                        <select name="rodada_id" class="form-select" required>
                            <?php foreach ($rodadas as $r): ?>
                                <option value="<?= $r['id'] ?>" <?= ($j['rodada_id'] == $r['id'] ? "selected" : "") ?>>
                                    Rodada <?= htmlspecialchars($r['numero']) ?> (limite <?= htmlspecialchars($r['data_limite']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Time 1</label>
                        <input type="text" name="time1" class="form-control" list="listaTimes"
                               value="<?= htmlspecialchars($j['time1']) ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Time 2</label>
                        <input type="text" name="time2" class="form-control" list="listaTimes"
                               value="<?= htmlspecialchars($j['time2']) ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Data</label>
                        <input type="datetime-local" name="data" class="form-control"
                               value="<?= date('Y-m-d\TH:i', strtotime($j['data'])) ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Placar</label>
                        <div class="input-group">
                            <input type="number" name="gol1" class="form-control" value="<?= htmlspecialchars($j['gol1']) ?>">
                            <span class="input-group-text">x</span>
                            <input type="number" name="gol2" class="form-control" value="<?= htmlspecialchars($j['gol2']) ?>">
                        </div>
                    </div>

                </div>

                <div class="modal-footer">
                    <button type="submit" name="edit" class="btn btn-warning text-dark fw-bold">
                        <i class="bi bi-save"></i> Salvar
                    </button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                </div>

            </form>
        </div>
    </div>

    <!-- Modal Excluir -->
    <div class="modal fade" id="deleteModal<?= (int)$j['id'] ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <form method="POST" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>" class="modal-content">

                <div class="modal-header bg-black text-warning">
                    <h5 class="modal-title"><i class="bi bi-exclamation-triangle"></i> Confirmar Exclusão</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    Tem certeza que deseja excluir o jogo
                    <strong><?= htmlspecialchars($j['time1']) ?> x <?= htmlspecialchars($j['time2']) ?></strong>?
                    <input type="hidden" name="id" value="<?= (int)$j['id'] ?>">
                </div>

                <div class="modal-footer">
                    <button type="submit" name="delete" class="btn btn-dark">
                        <i class="bi bi-trash text-danger"></i> Excluir
                    </button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                </div>

            </form>
        </div>
    </div>

<?php endforeach; ?>

<?php include "../includes/footer.php"; ?>
