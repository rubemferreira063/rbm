<?php
include "../includes/db.php";
include "../includes/header.php";

// Filtro de rodada
$rodada_id = $_GET['rodada_id'] ?? "";

// Buscar rodadas
$rodadas = $pdo->query("SELECT * FROM rodadas ORDER BY numero ASC")->fetchAll(PDO::FETCH_ASSOC);

// Buscar jogos com filtro
if ($rodada_id) {
    $stmt = $pdo->prepare("SELECT j.*, r.numero AS rodada 
                           FROM jogos j 
                           JOIN rodadas r ON j.rodada_id = r.id 
                           WHERE j.rodada_id = ?
                           ORDER BY j.data ASC");
    $stmt->execute([$rodada_id]);
    $jogos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    $jogos = $pdo->query("SELECT j.*, r.numero AS rodada 
                          FROM jogos j 
                          JOIN rodadas r ON j.rodada_id = r.id 
                          ORDER BY r.numero ASC, j.data ASC")->fetchAll(PDO::FETCH_ASSOC);
}

// Buscar participantes
$participantes = $pdo->query("SELECT * FROM participantes ORDER BY nome ASC")->fetchAll(PDO::FETCH_ASSOC);

// Montar matriz de palpites
$palpites = [];
$stmt = $pdo->query("SELECT * FROM palpites");
foreach ($stmt as $p) {
    $palpites[$p['jogo_id']][$p['participante_id']] = [
        'palpite1' => $p['palpite1'],
        'palpite2' => $p['palpite2']
    ];
}

// Função para ícone de acerto
function iconeAcerto($p1, $p2, $g1, $g2) {
    if ($g1 === null || $g2 === null) return ""; // jogo sem resultado
    if ($p1 == $g1 && $p2 == $g2) return "<span class='text-success fw-bold'>✅</span>";
    return "<span class='text-danger fw-bold'>❌</span>";
}
?>

<div class="container">

    <!-- FILTRO DE RODADA -->
    <div class="card border-dark mb-4">
        <div class="card-header bg-black text-warning">
            <i class="bi bi-funnel"></i> Filtrar por Rodada
        </div>
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-6">
                    <select name="rodada_id" class="form-select">
                        <option value="">Todas as rodadas</option>
                        <?php foreach ($rodadas as $r): ?>
                            <option value="<?= $r['id'] ?>" <?= ($rodada_id == $r['id'] ? "selected" : "") ?>>
                                Rodada <?= $r['numero'] ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <button class="btn btn-warning text-dark fw-bold">
                        <i class="bi bi-search"></i> Aplicar Filtro
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- BOTÃO EXPORTAR -->
    <div class="mb-3">
        <a href="tabela_geral_exportar.php<?= $rodada_id ? '?rodada_id='.$rodada_id : '' ?>" 
           class="btn btn-success fw-bold">
            <i class="bi bi-file-earmark-excel"></i> Exportar para Excel (CSV)
        </a>
    </div>

    <!-- TABELÃO -->
    <div class="card border-dark">
        <div class="card-header bg-black text-warning">
            <i class="bi bi-table"></i> Tabelão com Todos os Palpites
        </div>
        <div class="card-body table-responsive">

            <table class="table table-bordered table-striped table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Rodada</th>
                        <th>Jogo</th>
                        <th>Data</th>
                        <th>Resultado</th>
                        <?php foreach ($participantes as $p): ?>
                            <th class="text-center"><?= htmlspecialchars($p['nome']) ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach ($jogos as $j): ?>
                        <tr>
                            <td>Rodada <?= $j['rodada'] ?></td>

                            <td><?= $j['time1'] ?> x <?= $j['time2'] ?></td>

                            <td><?= date('d/m/Y H:i', strtotime($j['data'])) ?></td>

                            <td>
                                <?= ($j['gol1'] !== null && $j['gol2'] !== null) 
                                    ? "{$j['gol1']} x {$j['gol2']}" 
                                    : '-' ?>
                            </td>

                            <?php foreach ($participantes as $p): 
                                $palpite = $palpites[$j['id']][$p['id']] ?? null;
                            ?>
                                <td class="text-center">
                                    <?php if ($palpite): ?>
                                        <?= $palpite['palpite1'] ?> x <?= $palpite['palpite2'] ?>
                                        <?= iconeAcerto($palpite['palpite1'], $palpite['palpite2'], $j['gol1'], $j['gol2']) ?>
                                    <?php else: ?>
                                        <span class="text-muted">–</span>
                                    <?php endif; ?>
                                </td>
                            <?php endforeach; ?>

                        </tr>
                    <?php endforeach; ?>
                </tbody>

            </table>

        </div>
    </div>
</div>

<?php include "../includes/footer.php"; ?>

