<?php
include "../includes/db.php";
include "../includes/header.php";

// Se tiver uma função de pontuação em outro arquivo, inclua aqui.
// include "../includes/functions.php";

$alert = "";

// Atualizar resultado e recalcular pontos
if (isset($_POST['update'])) {
    $id = $_POST['id'] ?? null;
    $gol1 = ($_POST['gol1'] !== "" ? $_POST['gol1'] : null);
    $gol2 = ($_POST['gol2'] !== "" ? $_POST['gol2'] : null);

    if ($id) {
        $stmt = $pdo->prepare("UPDATE jogos SET gol1=?, gol2=? WHERE id=?");
        if ($stmt->execute([$gol1, $gol2, $id])) {

            // Buscar jogo atualizado
            $stmtJogo = $pdo->prepare("SELECT * FROM jogos WHERE id=?");
            $stmtJogo->execute([$id]);
            $jogo = $stmtJogo->fetch(PDO::FETCH_ASSOC);

            // Buscar palpites desse jogo
            $stmtPalpites = $pdo->prepare("SELECT * FROM palpites WHERE jogo_id=?");
            $stmtPalpites->execute([$id]);
            $palpites = $stmtPalpites->fetchAll(PDO::FETCH_ASSOC);

            // Nota: esta função precisa existir (em um include ou aqui)
            if (!function_exists('calcularPontuacao')) {
                function calcularPontuacao($p1, $p2, $g1, $g2, $t1, $t2) {
                    // Exemplo simples de regra:
                    // 3 pts acerto exato, 1 pt acerto do vencedor/empate, 0 caso contrário.
                    if ($g1 === null || $g2 === null) return 0;
                    if ($p1 == $g1 && $p2 == $g2) return 3;
                    $resultadoReal = ($g1 > $g2) ? 1 : (($g1 < $g2) ? 2 : 0);
                    $resultadoPalpite = ($p1 > $p2) ? 1 : (($p1 < $p2) ? 2 : 0);
                    return ($resultadoReal === $resultadoPalpite) ? 1 : 0;
                }
            }

            foreach ($palpites as $p) {
                $pontos = calcularPontuacao($p['palpite1'], $p['palpite2'], $gol1, $gol2, $jogo['time1'], $jogo['time2']);

                // Atualizar ou inserir pontuação acumulando por participante/rodada
                $stmtPontuacao = $pdo->prepare("INSERT INTO pontuacoes (participante_id, rodada_id, pontos)
                                                VALUES (?, ?, ?)
                                                ON DUPLICATE KEY UPDATE pontos = pontos + VALUES(pontos)");
                $stmtPontuacao->execute([$p['participante_id'], $jogo['rodada_id'], $pontos]);
            }

            $alert = '<div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <i class="bi bi-pencil-square"></i> Resultado atualizado e pontuações recalculadas!
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                      </div>';
        } else {
            $alert = '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="bi bi-x-circle"></i> Erro ao atualizar resultado.
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                      </div>';
        }
    }
}

// Excluir jogo
if (isset($_POST['delete'])) {
    $id = $_POST['id'] ?? null;
    if ($id) {
        $stmt = $pdo->prepare("DELETE FROM jogos WHERE id=?");
        if ($stmt->execute([$id])) {
            $alert = '<div class="alert alert-dark alert-dismissible fade show" role="alert">
                        <i class="bi bi-trash"></i> Jogo excluído com sucesso!
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                      </div>';
        } else {
            $alert = '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="bi bi-x-circle"></i> Erro ao excluir jogo.
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                      </div>';
        }
    }
}

// Busca
$search = $_GET['search'] ?? "";
$query = "SELECT j.*, r.numero AS rodada_numero
          FROM jogos j
          JOIN rodadas r ON j.rodada_id = r.id
          WHERE r.numero LIKE ? OR j.time1 LIKE ? OR j.time2 LIKE ?
          ORDER BY j.data ASC";
$stmt = $pdo->prepare($query);
$stmt->execute(["%$search%", "%$search%", "%$search%"]);
$jogos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container">
    <?= $alert ?>

     <!-- Busca -->
    <form class="d-flex mb-3" method="GET" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>">
        <input class="form-control me-2" type="search" name="search" placeholder="Buscar por rodada ou time..." value="<?= htmlspecialchars($search) ?>">
        <button class="btn btn-warning text-dark fw-bold" type="submit">
            <i class="bi bi-search"></i> Buscar
        </button>
    </form>

    <!-- Lista de jogos -->
    <div class="card border-dark">
        <div class="card-header bg-black text-warning">
            <i class="bi bi-list"></i> Resultados dos Jogos
        </div>
        <div class="card-body">
            <table class="table table-striped align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Rodada</th>
                        <th>Time 1</th>
                        <th>Time 2</th>
                        <th>Data</th>
                        <th>Placar</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($jogos)): ?>
                        <?php foreach ($jogos as $j): ?>
                            <tr>
                                <td><?= (int)$j['id'] ?></td>
                                <td>Rodada <?= htmlspecialchars($j['rodada_numero']) ?></td>
                                <td><?= htmlspecialchars($j['time1']) ?></td>
                                <td><?= htmlspecialchars($j['time2']) ?></td>
                                <td><?= date('d/m/Y H:i', strtotime($j['data'])) ?></td>
                                <td>
                                    <?= ($j['gol1'] !== null && $j['gol2'] !== null)
                                        ? '<span class="badge bg-warning text-dark">'.htmlspecialchars($j['gol1']).' x '.htmlspecialchars($j['gol2']).'</span>'
                                        : '-' ?>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-warning text-dark" data-bs-toggle="modal" data-bs-target="#updateModal<?= (int)$j['id'] ?>">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <button class="btn btn-sm btn-dark" data-bs-toggle="modal" data-bs-target="#deleteModal<?= (int)$j['id'] ?>">
                                        <i class="bi bi-trash text-danger"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center">
                                <div class="alert alert-info mb-0">
                                    <i class="bi bi-info-circle"></i> Nenhum jogo encontrado.
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modais fora da tabela -->
<?php foreach ($jogos as $j): ?>
    <!-- Modal Atualizar Resultado -->
    <div class="modal fade" id="updateModal<?= (int)$j['id'] ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <form method="POST" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>" class="modal-content">
                <div class="modal-header bg-black text-warning">
                    <h5 class="modal-title"><i class="bi bi-pencil-square"></i> Atualizar Resultado</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="id" value="<?= (int)$j['id'] ?>">
                    <div class="mb-3">
                        <label class="form-label"><?= htmlspecialchars($j['time1']) ?></label>
                        <input type="number" name="gol1" class="form-control" value="<?= htmlspecialchars($j['gol1']) ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?= htmlspecialchars($j['time2']) ?></label>
                        <input type="number" name="gol2" class="form-control" value="<?= htmlspecialchars($j['gol2']) ?>">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" name="update" class="btn btn-warning text-dark fw-bold">
                        <i class="bi bi-save"></i> Salvar
                    </button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Excluir -->
    <div class="modal fade" id="deleteModal<?= (int)$j['id'] ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <form method="POST" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>" class="modal-content">
                <div class="modal-header bg-black text-warning">
                    <h5 class="modal-title"><i class="bi bi-exclamation-triangle"></i> Confirmar Exclusão</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    Tem certeza que deseja excluir o jogo <strong><?= htmlspecialchars($j['time1']) ?> x <?= htmlspecialchars($j['time2']) ?></strong>?
                    <input type="hidden" name="id" value="<?= (int)$j['id'] ?>">
                </div>
                <div class="modal-footer">
                    <button type="submit" name="delete" class="btn btn-dark">
                        <i class="bi bi-trash text-danger"></i> Excluir
                    </button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                </div>
            </form>
        </div>
    </div>
<?php endforeach; ?>

<?php include "../includes/footer.php"; ?>
