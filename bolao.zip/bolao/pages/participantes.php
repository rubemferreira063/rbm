<?php
include "../includes/db.php";
include "../includes/header.php";

$alert = "";

// Adicionar participante
if (isset($_POST['add'])) {
    $nome = $_POST['nome'] ?? '';
    $telefone = $_POST['telefone'] ?? '';
    $pago = isset($_POST['pago']) ? 1 : 0;

    $stmt = $pdo->prepare("INSERT INTO participantes (nome, telefone, pago) VALUES (?, ?, ?)");
    if ($stmt->execute([$nome, $telefone, $pago])) {
        $alert = '<div class="alert alert-success">Participante cadastrado com sucesso!</div>';
    } else {
        $alert = '<div class="alert alert-danger">Erro ao cadastrar participante.</div>';
    }
}

// Editar participante
if (isset($_POST['edit'])) {
    $id = $_POST['id'] ?? null;
    $nome = $_POST['nome'] ?? '';
    $telefone = $_POST['telefone'] ?? '';
    $pago = isset($_POST['pago']) ? 1 : 0;

    if ($id) {
        $stmt = $pdo->prepare("UPDATE participantes SET nome=?, telefone=?, pago=? WHERE id=?");
        if ($stmt->execute([$nome, $telefone, $pago, $id])) {
            $alert = '<div class="alert alert-warning">Participante atualizado com sucesso!</div>';
        } else {
            $alert = '<div class="alert alert-danger">Erro ao atualizar participante.</div>';
        }
    }
}

// Excluir participante
if (isset($_POST['delete'])) {
    $id = $_POST['id'] ?? null;
    if ($id) {
        $stmt = $pdo->prepare("DELETE FROM participantes WHERE id=?");
        if ($stmt->execute([$id])) {
            $alert = '<div class="alert alert-dark">Participante excluído com sucesso!</div>';
        } else {
            $alert = '<div class="alert alert-danger">Erro ao excluir participante.</div>';
        }
    }
}

// Busca
$search = $_GET['search'] ?? "";
$query = "SELECT * FROM participantes WHERE nome LIKE ? ORDER BY id DESC";
$stmt = $pdo->prepare($query);
$stmt->execute(["%$search%"]);
$participantes = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="container">
    <?= $alert ?>

    <!-- Formulário de cadastro -->
    <div class="card mb-4 border-dark">
        <div class="card-header bg-black text-warning">
            <i class="bi bi-person-plus"></i> Adicionar Participante
        </div>
        <div class="card-body">
            <form method="POST" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>">
                <div class="mb-3">
                    <label class="form-label">Nome</label>
                    <input type="text" name="nome" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Telefone</label>
                    <input type="text" name="telefone" class="form-control">
                </div>
                <div class="form-check mb-3">
                    <input class="form-check-input" type="checkbox" name="pago" id="pago">
                    <label class="form-check-label" for="pago">Contribuição paga</label>
                </div>
                <button type="submit" name="add" class="btn btn-dark">
                    <i class="bi bi-check-circle"></i> Cadastrar
                </button>
            </form>
        </div>
    </div>

    <!-- Busca -->
    <form class="d-flex mb-3" method="GET">
        <input class="form-control me-2" type="search" name="search" placeholder="Buscar participante..." value="<?= htmlspecialchars($search) ?>">
        <button class="btn btn-warning text-dark fw-bold" type="submit"><i class="bi bi-search"></i> Buscar</button>
    </form>

    <!-- Lista de participantes -->
    <div class="card border-dark">
        <div class="card-header bg-black text-warning">
            <i class="bi bi-people"></i> Lista de Participantes
        </div>
        <div class="card-body">
            <table class="table table-striped align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>Telefone</th>
                        <th>Pago</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($participantes)): ?>
                        <?php foreach ($participantes as $p): ?>
                            <tr>
                                <td><?= (int)$p['id'] ?></td>
                                <td><?= htmlspecialchars($p['nome']) ?></td>
                                <td><?= htmlspecialchars($p['telefone']) ?></td>
                                <td>
                                    <?= $p['pago'] ? '<span class="badge bg-warning text-dark">Sim</span>' : '<span class="badge bg-dark">Não</span>' ?>
                                </td>
                                <td>
                                    <!-- Botão Editar -->
                                    <button class="btn btn-sm btn-warning text-dark" data-bs-toggle="modal" data-bs-target="#editModal<?= (int)$p['id'] ?>">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <!-- Botão Excluir -->
                                    <button class="btn btn-sm btn-dark" data-bs-toggle="modal" data-bs-target="#deleteModal<?= (int)$p['id'] ?>">
                                        <i class="bi bi-trash text-danger"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center">
                                <div class="alert alert-info mb-0"><i class="bi bi-info-circle"></i> Nenhum participante encontrado.</div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modais fora da tabela -->
<?php foreach ($participantes as $p): ?>
    <!-- Modal Editar -->
    <div class="modal fade" id="editModal<?= (int)$p['id'] ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <form method="POST" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>" class="modal-content">
                <div class="modal-header bg-black text-warning">
                    <h5 class="modal-title"><i class="bi bi-pencil-square"></i> Editar Participante</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                    <div class="mb-3">
                        <label class="form-label">Nome</label>
                        <input type="text" name="nome" class="form-control" value="<?= htmlspecialchars($p['nome']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Telefone</label>
                        <input type="text" name="telefone" class="form-control" value="<?= htmlspecialchars($p['telefone']) ?>">
                    </div>
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" name="pago" <?= !empty($p['pago']) ? "checked" : "" ?>>
                        <label class="form-check-label">Contribuição paga</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" name="edit" class="btn btn-warning text-dark fw-bold"><i class="bi bi-save"></i> Salvar</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Excluir -->
    <div class="modal fade" id="deleteModal<?= (int)$p['id'] ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <form method="POST" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>" class="modal-content">
                <div class="modal-header bg-black text-warning">
                    <h5 class="modal-title"><i class="bi bi-exclamation-triangle"></i> Confirmar Exclusão</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    Tem certeza que deseja excluir <strong><?= htmlspecialchars($p['nome']) ?></strong>?
                    <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                </div>
                <div class="modal-footer">
                   <div class="modal-footer">
    <button type="submit" name="delete" class="btn btn-dark">
        <i class="bi bi-trash text-danger"></i> Excluir
    </button>
    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
</div>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                </div>
            </form>
        </div>
    </div>
<?php endforeach; ?>
<?php include "../includes/footer.php"; ?>