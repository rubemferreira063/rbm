<?php
include "../includes/db.php";
include "../includes/header.php";
include "../includes/functions.php"; // calcularPontuacao() e exibirPontuacaoBadge()

$alert = "";

// Adicionar palpites
if (isset($_POST['add'])) {
    $participante_id = $_POST['participante_id'];
    $rodada_id = $_POST['rodada_id'];

    // Buscar jogos da rodada
    $stmt = $pdo->prepare("SELECT * FROM jogos WHERE rodada_id=? ORDER BY data ASC");
    $stmt->execute([$rodada_id]);
    $jogos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($jogos as $jogo) {
        $palpite1 = (isset($_POST['palpite1_'.$jogo['id']]) && $_POST['palpite1_'.$jogo['id']] !== '' 
                     ? (int)$_POST['palpite1_'.$jogo['id']] 
                     : null);

        $palpite2 = (isset($_POST['palpite2_'.$jogo['id']]) && $_POST['palpite2_'.$jogo['id']] !== '' 
                     ? (int)$_POST['palpite2_'.$jogo['id']] 
                     : null);

        if ($palpite1 !== null || $palpite2 !== null) {
            $stmtInsert = $pdo->prepare("INSERT INTO palpites (participante_id, jogo_id, palpite1, palpite2)  
                                         VALUES (?, ?, ?, ?)  
                                         ON DUPLICATE KEY UPDATE palpite1=VALUES(palpite1), palpite2=VALUES(palpite2)");
            $stmtInsert->execute([$participante_id, $jogo['id'], $palpite1, $palpite2]);
        }
    }

    // Verificar se o participante deixou palpites incompletos
    $stmtCheck = $pdo->prepare("SELECT COUNT(*) AS total, 
                                       SUM(CASE WHEN palpite1 IS NOT NULL AND palpite2 IS NOT NULL THEN 1 ELSE 0 END) AS preenchidos
                                FROM palpites 
                                WHERE participante_id = ? AND jogo_id IN (SELECT id FROM jogos WHERE rodada_id = ?)");
    $stmtCheck->execute([$participante_id, $rodada_id]);
    $dadosCheck = $stmtCheck->fetch(PDO::FETCH_ASSOC);

    if ($dadosCheck['preenchidos'] < $dadosCheck['total']) {
        $alert = '<div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle"></i> Você ainda não deu palpite em todos os jogos desta rodada.
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                  </div>';
    } else {
        $alert = '<div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle"></i> Todos os palpites foram registrados com sucesso!
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                  </div>';
    }
}

// Editar palpite
if (isset($_POST['edit'])) {
    $participante_id = $_POST['participante_id'];
    $rodada_id = $_POST['rodada_id'];
    $jogo_id = $_POST['jogo_id'];
    $palpite1 = ($_POST['palpite1'] !== '' ? (int)$_POST['palpite1'] : null);
    $palpite2 = ($_POST['palpite2'] !== '' ? (int)$_POST['palpite2'] : null);

    $stmtEdit = $pdo->prepare("INSERT INTO palpites (participante_id, jogo_id, palpite1, palpite2)
                               VALUES (?, ?, ?, ?)
                               ON DUPLICATE KEY UPDATE palpite1=VALUES(palpite1), palpite2=VALUES(palpite2)");
    $stmtEdit->execute([$participante_id, $jogo_id, $palpite1, $palpite2]);

    $alert = '<div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-pencil"></i> Palpite atualizado com sucesso!
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
              </div>';
}

// Excluir palpite
if (isset($_POST['delete'])) {
    $id = $_POST['id'];
    $participante_id = $_POST['participante_id'] ?? null;
    $rodada_id = $_POST['rodada_id'] ?? null;

    $stmt = $pdo->prepare("DELETE FROM palpites WHERE id=?");
    if ($stmt->execute([$id])) {
        $alert = '<div class="alert alert-dark alert-dismissible fade show" role="alert">
                    <i class="bi bi-trash"></i> Palpite excluído com sucesso!
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                  </div>';
    }
}

// Buscar participantes e rodadas
$participantes = $pdo->query("SELECT * FROM participantes ORDER BY nome ASC")->fetchAll(PDO::FETCH_ASSOC);
$rodadas = $pdo->query("SELECT * FROM rodadas ORDER BY numero ASC")->fetchAll(PDO::FETCH_ASSOC);

// Se rodada selecionada
$rodada_id = $_GET['rodada_id'] ?? $rodada_id ?? null;
$jogos = [];
if ($rodada_id) {
    $stmt = $pdo->prepare("SELECT * FROM jogos WHERE rodada_id=? ORDER BY data ASC");
    $stmt->execute([$rodada_id]);
    $jogos = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Buscar palpites já realizados do participante selecionado
$palpitesRealizados = [];
$participante_id = $_POST['participante_id'] ?? $_GET['participante_id'] ?? $participante_id ?? null;
if ($participante_id) {
    $stmtPalpites = $pdo->prepare("SELECT pa.*, j.time1, j.time2, j.gol1, j.gol2, r.numero AS rodada
                                   FROM palpites pa
                                   JOIN jogos j ON pa.jogo_id = j.id
                                   JOIN rodadas r ON j.rodada_id = r.id
                                   WHERE pa.participante_id = ?
                                   ORDER BY r.numero ASC, j.data ASC");
    $stmtPalpites->execute([$participante_id]);
    $palpitesRealizados = $stmtPalpites->fetchAll(PDO::FETCH_ASSOC);
}
?>

<div class="container">
    <?= $alert ?>

    <!-- Seleção de participante e rodada -->
    <div class="card mb-4 border-dark">
        <div class="card-header bg-black text-warning">
            <i class="bi bi-pencil-square"></i> Registrar Palpites
        </div>
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Rodada</label>
                    <select name="rodada_id" class="form-select" required>
                        <option value="">Selecione...</option>
                        <?php foreach ($rodadas as $r): ?>
                            <option value="<?= $r['id'] ?>" <?= ($rodada_id==$r['id'] ? "selected" : "") ?>>
                                Rodada <?= $r['numero'] ?> (limite <?= $r['data_limite'] ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <button type="submit" class="btn btn-warning text-dark fw-bold mt-4">
                        <i class="bi bi-search"></i> Buscar Jogos
                    </button>
                </div>
            </form>
        </div>
    </div>

    <?php if ($rodada_id && !empty($jogos)): ?>
        <div class="card border-dark">
            <div class="card-header bg-black text-warning">
                <i class="bi bi-list"></i> Jogos da Rodada
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="rodada_id" value="<?= $rodada_id ?>">
                    <div class="mb-3">
                        <label class="form-label">Participante</label>
                        <select name="participante_id" class="form-select" required>
                            <option value="">Selecione...</option>
                            <?php foreach ($participantes as $p): ?>
                                <option value="<?= $p['id'] ?>" <?= ($participante_id==$p['id'] ? "selected" : "") ?>>
                                    <?= htmlspecialchars($p['nome']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <table class="table table-striped align-middle">
                        <thead class="table-dark">
                            <tr>
                                <th>Jogo</th>
                                <th>Data</th>
                                <th>Palpite</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($jogos as $j): ?>
                                <tr>
                                    <td><?= htmlspecialchars($j['time1']) ?> x <?= htmlspecialchars($j['time2']) ?></td>
                                    <td><?= date('d/m/Y H:i', strtotime($j['data'])) ?></td>
                                    <td>
                                        <div class="input-group">
                                            <input type="number" name="palpite1_<?= $j['id'] ?>" class="form-control" placeholder="<?= $j['time1'] ?>" min="0">
                                            <span class="input-group-text">x</span>
                                            <input type="number" name="palpite2_<?= $j['id'] ?>" class="form-control" placeholder="<?= $j['time2'] ?>" min="0">
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <button type="submit" name="add" class="btn btn-dark">
                        <i class="bi bi-check-circle"></i> Salvar Palpites
                    </button>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <!-- Palpites já realizados do participante -->
    <?php if (!empty($palpitesRealizados)): ?>
        <div class="card mt-4 border-dark">
            <div class="card-header bg-black text-warning">
                <i class="bi bi-list-check"></i> Seus Palpites Realizados
            </div>
            <div class="card-body">
                <table class="table table-striped align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>Rodada</th>
                            <th>Jogo</th>
                            <th>Palpite</th>
                            <th>Resultado</th>
                            <th>Pontos</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($palpitesRealizados as $pa): ?>
                            <tr>
                                <td>Rodada <?= $pa['rodada'] ?></td>
                                <td><?= htmlspecialchars($pa['time1']) ?> x <?= htmlspecialchars($pa['time2']) ?></td>
                                <td>
                                    <form method="POST" class="d-flex align-items-center">
                                        <input type="hidden" name="rodada_id" value="<?= $rodada_id ?>">
                                        <input type="hidden" name="participante_id" value="<?= $participante_id ?>">
                                        <input type="hidden" name="jogo_id" value="<?= $pa['jogo_id'] ?>">
                                        <input type="number" name="palpite1" value="<?= $pa['palpite1'] ?>" class="form-control w-25" min="0">
                                        <span class="mx-2 fw-bold">x</span>
                                        <input type="number" name="palpite2" value="<?= $pa['palpite2'] ?>" class="form-control w-25" min="0">
                                        <button type="submit" name="edit" class="btn btn-sm btn-outline-success ms-2">
                                            <i class="bi bi-save"></i> Salvar
                                        </button>
                                    </form>
                                </td>
                                <td>
                                    <?= ($pa['gol1'] !== null && $pa['gol2'] !== null) 
                                        ? $pa['gol1']." x ".$pa['gol2'] 
                                        : '<span class="badge bg-secondary">-</span>' ?>
                                </td>
                                <td>
                                    <?php
                                    if ($pa['gol1'] !== null && $pa['gol2'] !== null && $pa['palpite1'] !== null && $pa['palpite2'] !== null) {
                                        echo exibirPontuacaoBadge(
                                            calcularPontuacao(
                                                (int)$pa['palpite1'],
                                                (int)$pa['palpite2'],
                                                (int)$pa['gol1'],
                                                (int)$pa['gol2'],
                                                $pa['time1'],
                                                $pa['time2']
                                            )
                                        );
                                    } else {
                                        echo '<span class="badge bg-secondary">-</span>';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <form method="POST" style="display:inline;">
                                        <input type="hidden" name="id" value="<?= $pa['id'] ?>">
                                        <input type="hidden" name="participante_id" value="<?= $participante_id ?>">
                                        <input type="hidden" name="rodada_id" value="<?= $rodada_id ?>">
                                        <button type="submit" name="delete" class="btn btn-sm btn-outline-danger" onclick="return confirm('Excluir este palpite?')">
                                            <i class="bi bi-trash"></i> Excluir
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php include "../includes/footer.php"; ?>