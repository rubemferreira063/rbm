<?php
include "../includes/db.php";
include "../includes/header.php";
include "../includes/functions.php"; // contém calcularPontuacao()

$alert = "";

// Buscar rodadas
$rodadas = $pdo->query("SELECT * FROM rodadas ORDER BY numero ASC")->fetchAll(PDO::FETCH_ASSOC);

// Rodada selecionada
$rodada_id = $_GET['rodada_id'] ?? null;
$ranking = [];

if ($rodada_id) {
    // Buscar participantes
    $participantes = $pdo->query("SELECT * FROM participantes ORDER BY nome ASC")->fetchAll(PDO::FETCH_ASSOC);

    foreach ($participantes as $p) {
        $stmt = $pdo->prepare("SELECT pa.*, j.time1, j.time2, j.gol1, j.gol2
                               FROM palpites pa
                               JOIN jogos j ON pa.jogo_id = j.id
                               WHERE pa.participante_id=? AND j.rodada_id=?");
        $stmt->execute([$p['id'], $rodada_id]);
        $palpites = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $total_pontos = 0;
        $placares_exatos = 0;
        $exatos_galo = 0;
        $gols_acertados = 0;

        foreach ($palpites as $palpite) {
            if ($palpite['gol1'] !== null && $palpite['gol2'] !== null) {
                $pontos = calcularPontuacao(
                    $palpite['palpite1'],
                    $palpite['palpite2'],
                    $palpite['gol1'],
                    $palpite['gol2'],
                    $palpite['time1'],
                    $palpite['time2']
                );

                $total_pontos += $pontos;

                // Estatísticas extras
                if ($palpite['palpite1'] == $palpite['gol1'] && $palpite['palpite2'] == $palpite['gol2']) {
                    $placares_exatos++;
                    if ($palpite['time1'] == "Atlético MG" || $palpite['time2'] == "Atlético MG") {
                        $exatos_galo++;
                    }
                }
                if ($palpite['palpite1'] == $palpite['gol1']) $gols_acertados++;
                if ($palpite['palpite2'] == $palpite['gol2']) $gols_acertados++;
            }
        }

        $ranking[] = [
            'nome' => $p['nome'],
            'pontos' => $total_pontos,
            'placares_exatos' => $placares_exatos,
            'exatos_galo' => $exatos_galo,
            'gols_acertados' => $gols_acertados
        ];
    }

    // Ordenar ranking por pontos decrescentes
    usort($ranking, function($a, $b) {
        return $b['pontos'] <=> $a['pontos'];
    });
}
?>

<div class="container">
    <div class="card mb-4">
        <div class="card-header bg-dark text-white">
            <i class="bi bi-bar-chart"></i> Relatório por Rodada
        </div>
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Selecione a Rodada</label>
                    <select name="rodada_id" class="form-select" required>
                        <option value="">Escolha...</option>
                        <?php foreach ($rodadas as $r): ?>
                            <option value="<?= $r['id'] ?>" <?= ($rodada_id==$r['id'] ? "selected" : "") ?>>
                                Rodada <?= $r['numero'] ?> (limite <?= $r['data_limite'] ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <button type="submit" class="btn btn-primary mt-4"><i class="bi bi-search"></i> Gerar Relatório</button>
                </div>
            </form>
        </div>
    </div>

    <?php if ($rodada_id && !empty($ranking)): ?>
        <div class="card">
            <div class="card-header bg-secondary text-white">
                <i class="bi bi-list-ol"></i> Resultados da Rodada <?= htmlspecialchars($rodada_id) ?>
            </div>
            <div class="card-body">
                <table class="table table-striped align-middle">
                    <thead>
                        <tr>
                            <th>Posição</th>
                            <th>Participante</th>
                            <th>Pontos</th>
                            <th>Placares Exatos</th>
                            <th>Exatos do Galo</th>
                            <th>Gols Acertados</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $pos = 1; foreach ($ranking as $r): ?>
                            <tr>
                                <td><span class="badge bg-primary"><?= $pos++ ?>º</span></td>
                                <td><?= htmlspecialchars($r['nome']) ?></td>
                                <td><strong><?= $r['pontos'] ?></strong></td>
                                <td><?= $r['placares_exatos'] ?></td>
                                <td><?= $r['exatos_galo'] ?></td>
                                <td><?= $r['gols_acertados'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php elseif ($rodada_id): ?>
        <div class="alert alert-info"><i class="bi bi-info-circle"></i> Nenhum palpite registrado para esta rodada.</div>
    <?php endif; ?>
</div>

<?php include "../includes/footer.php"; ?>