<?php
include "../includes/db.php";
include "../includes/header.php";
include "../includes/functions.php"; // calcularPontuacao() e exibirPontuacaoBadge()

$alert = "";

// Buscar participantes e rodadas
$participantes = $pdo->query("SELECT * FROM participantes ORDER BY nome ASC")->fetchAll(PDO::FETCH_ASSOC);
$rodadas = $pdo->query("SELECT * FROM rodadas ORDER BY numero ASC")->fetchAll(PDO::FETCH_ASSOC);

// Filtro de rodada
$rodada_id = $_GET['rodada_id'] ?? null;

$ranking = [];

foreach ($participantes as $p) {
    if ($rodada_id) {
        // Palpites apenas da rodada selecionada
        $stmt = $pdo->prepare("SELECT pa.*, j.time1, j.time2, j.gol1, j.gol2, j.rodada_id  
                               FROM palpites pa  
                               JOIN jogos j ON pa.jogo_id = j.id  
                               WHERE pa.participante_id=? AND j.rodada_id=?");
        $stmt->execute([$p['id'], $rodada_id]);
    } else {
        // Palpites de todas as rodadas
        $stmt = $pdo->prepare("SELECT pa.*, j.time1, j.time2, j.gol1, j.gol2, j.rodada_id  
                               FROM palpites pa  
                               JOIN jogos j ON pa.jogo_id = j.id  
                               WHERE pa.participante_id=?");
        $stmt->execute([$p['id']]);
    }
    $palpites = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $total_pontos = 0;
    $placares_exatos = 0;
    $exatos_galo = 0;
    $gols_acertados = 0;

    foreach ($palpites as $palpite) {
        if ($palpite['gol1'] !== null && $palpite['gol2'] !== null) {
            $pontos = calcularPontuacao(
                (int)$palpite['palpite1'],
                (int)$palpite['palpite2'],
                (int)$palpite['gol1'],
                (int)$palpite['gol2'],
                $palpite['time1'],
                $palpite['time2']
            );

            $total_pontos += $pontos;

            if ($palpite['palpite1'] == $palpite['gol1'] && $palpite['palpite2'] == $palpite['gol2']) {
                $placares_exatos++;
                if ($palpite['time1'] == "Atlético MG" || $palpite['time2'] == "Atlético MG") {
                    $exatos_galo++;
                }
            }
            if ($palpite['palpite1'] == $palpite['gol1']) $gols_acertados++;
            if ($palpite['palpite2'] == $palpite['gol2']) $gols_acertados++;
        }
    }

    // Verificar palpites incompletos (considerando filtro)
    if ($rodada_id) {
        $stmtCheck = $pdo->prepare("SELECT COUNT(*) AS total, 
                                           SUM(CASE WHEN palpite1 IS NOT NULL AND palpite2 IS NOT NULL THEN 1 ELSE 0 END) AS preenchidos
                                    FROM palpites 
                                    WHERE participante_id = ? AND jogo_id IN (SELECT id FROM jogos WHERE rodada_id = ?)");
        $stmtCheck->execute([$p['id'], $rodada_id]);
    } else {
        $stmtCheck = $pdo->prepare("SELECT COUNT(*) AS total, 
                                           SUM(CASE WHEN palpite1 IS NOT NULL AND palpite2 IS NOT NULL THEN 1 ELSE 0 END) AS preenchidos
                                    FROM palpites 
                                    WHERE participante_id = ?");
        $stmtCheck->execute([$p['id']]);
    }
    $dadosCheck = $stmtCheck->fetch(PDO::FETCH_ASSOC);

    $incompleto = ($dadosCheck['preenchidos'] < $dadosCheck['total']);
    $faltando = $dadosCheck['total'] - $dadosCheck['preenchidos'];

    $ranking[] = [
        'nome' => $p['nome'],
        'pontos' => $total_pontos,
        'placares_exatos' => $placares_exatos,
        'exatos_galo' => $exatos_galo,
        'gols_acertados' => $gols_acertados,
        'incompleto' => $incompleto,
        'faltando' => $faltando
    ];
}

// Ordenar ranking por pontos decrescentes
usort($ranking, function($a, $b) {
    return $b['pontos'] <=> $a['pontos'];
});
?>

<div class="container">

    <!-- Filtro de rodada -->
    <form method="GET" class="row g-3 mb-4">
        <div class="col-md-6">
            <label class="form-label">Filtrar por Rodada</label>
            <select name="rodada_id" class="form-select">
                <option value="">Todas as rodadas</option>
                <?php foreach ($rodadas as $r): ?>
                    <option value="<?= $r['id'] ?>" <?= ($rodada_id==$r['id'] ? "selected" : "") ?>>
                        Rodada <?= $r['numero'] ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-6">
            <button type="submit" class="btn btn-warning text-dark fw-bold mt-4">
                <i class="bi bi-filter"></i> Filtrar
            </button>
        </div>
    </form>

    <div class="card border-dark">
        <div class="card-header bg-black text-warning">
            <i class="bi bi-trophy"></i> 
            <?php if ($rodada_id): ?>
                Classificação da Rodada <?= htmlspecialchars($rodada_id) ?>
            <?php else: ?>
                Classificação Geral do Bolão
            <?php endif; ?>
        </div>
        <div class="card-body">
            <table class="table table-striped align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Posição</th>
                        <th>Participante</th>
                        <th>Pontos</th>
                        <th>Placares Exatos</th>
                        <th>Exatos do Galo</th>
                        <th>Gols Acertados</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $pos = 1; foreach ($ranking as $r): ?>
                        <tr>
                            <td><span class="badge bg-warning text-dark fw-bold"><?= $pos++ ?>º</span></td>
                            <td>
                                <?= htmlspecialchars($r['nome']) ?>
                                <?php if ($r['incompleto']): ?>
                                    <span class="badge bg-warning text-dark ms-2">
                                        <i class="bi bi-exclamation-triangle"></i> incompleto (faltam <?= $r['faltando'] ?>)
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td><?= exibirPontuacaoBadge($r['pontos']) ?></td>
                            <td><span class="badge bg-dark text-warning"><?= $r['placares_exatos'] ?></span></td>
                            <td><span class="badge bg-dark text-warning"><?= $r['exatos_galo'] ?></span></td>
                            <td><span class="badge bg-dark text-warning"><?= $r['gols_acertados'] ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include "../includes/footer.php"; ?>
