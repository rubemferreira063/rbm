<?php
include "../includes/db.php";
include "../includes/header.php";

$alert = "";

// Adicionar rodada
if (isset($_POST['add'])) {
    $numero = $_POST['numero'];
    $data_limite = $_POST['data_limite'];

    $stmt = $pdo->prepare("INSERT INTO rodadas (numero, data_limite) VALUES (?, ?)");
    if ($stmt->execute([$numero, $data_limite])) {
        $alert = '<div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle"></i> Rodada cadastrada com sucesso!
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                  </div>';
    }
}

// Editar rodada
if (isset($_POST['edit'])) {
    $id = $_POST['id'];
    $numero = $_POST['numero'];
    $data_limite = $_POST['data_limite'];

    $stmt = $pdo->prepare("UPDATE rodadas SET numero=?, data_limite=? WHERE id=?");
    if ($stmt->execute([$numero, $data_limite, $id])) {
        $alert = '<div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <i class="bi bi-pencil-square"></i> Rodada atualizada com sucesso!
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                  </div>';
    }
}

// Excluir rodada
if (isset($_POST['delete'])) {
    $id = $_POST['id'];
    $stmt = $pdo->prepare("DELETE FROM rodadas WHERE id=?");
    if ($stmt->execute([$id])) {
        $alert = '<div class="alert alert-dark alert-dismissible fade show" role="alert">
                    <i class="bi bi-trash"></i> Rodada excluída com sucesso!
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                  </div>';
    }
}

// Busca
$search = $_GET['search'] ?? "";
$query = "SELECT * FROM rodadas WHERE numero LIKE ? ORDER BY numero ASC";
$stmt = $pdo->prepare($query);
$stmt->execute(["%$search%"]);
$rodadas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="container">
    <?= $alert ?>

    <!-- Formulário de cadastro -->
    <div class="card mb-4 border-dark">
        <div class="card-header bg-black text-warning">
            <i class="bi bi-calendar-plus"></i> Adicionar Rodada
        </div>
        <div class="card-body">
            <form method="POST" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>">
                <div class="mb-3">
                    <label class="form-label">Número da Rodada</label>
                    <input type="number" name="numero" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Data Limite</label>
                    <input type="date" name="data_limite" class="form-control" required>
                </div>
                <button type="submit" name="add" class="btn btn-dark">
                    <i class="bi bi-check-circle"></i> Cadastrar
                </button>
            </form>
        </div>
    </div>

    <!-- Busca -->
    <form class="d-flex mb-3" method="GET">
        <input class="form-control me-2" type="search" name="search" placeholder="Buscar rodada..." value="<?= htmlspecialchars($search) ?>">
        <button class="btn btn-warning text-dark fw-bold" type="submit"><i class="bi bi-search"></i> Buscar</button>
    </form>

    <!-- Lista de rodadas -->
    <div class="card border-dark">
        <div class="card-header bg-black text-warning">
            <i class="bi bi-list-ol"></i> Lista de Rodadas
        </div>
        <div class="card-body">
            <table class="table table-striped align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Número</th>
                        <th>Data Limite</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($rodadas)): ?>
                        <?php foreach ($rodadas as $r): ?>
                            <tr>
                                <td><?= $r['id'] ?></td>
                                <td><?= htmlspecialchars($r['numero']) ?></td>
                                <td><?= htmlspecialchars($r['data_limite']) ?></td>
                                <td>
                                    <!-- Botão Editar -->
                                    <button class="btn btn-sm btn-warning text-dark" data-bs-toggle="modal" data-bs-target="#editModal<?= $r['id'] ?>">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <!-- Botão Excluir -->
                                    <button class="btn btn-sm btn-dark" data-bs-toggle="modal" data-bs-target="#deleteModal<?= $r['id'] ?>">
                                        <i class="bi bi-trash text-danger"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" class="text-center">
                                <div class="alert alert-info mb-0"><i class="bi bi-info-circle"></i> Nenhuma rodada encontrada.</div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modais fora da tabela -->
<?php foreach ($rodadas as $r): ?>
    <!-- Modal Editar -->
    <div class="modal fade" id="editModal<?= $r['id'] ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <form method="POST" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>" class="modal-content">
                <div class="modal-header bg-black text-warning">
                    <h5 class="modal-title"><i class="bi bi-pencil-square"></i> Editar Rodada</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="id" value="<?= $r['id'] ?>">
                    <div class="mb-3">
                        <label class="form-label">Número</label>
                        <input type="number" name="numero" class="form-control" value="<?= htmlspecialchars($r['numero']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Data Limite</label>
                        <input type="date" name="data_limite" class="form-control" value="<?= htmlspecialchars($r['data_limite']) ?>" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" name="edit" class="btn btn-warning text-dark fw-bold"><i class="bi bi-save"></i> Salvar</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Excluir -->
    <div class="modal fade" id="deleteModal<?= $r['id'] ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <form method="POST" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>" class="modal-content">
                <div class="modal-header bg-black text-warning">
                    <h5 class="modal-title"><i class="bi bi-exclamation-triangle"></i> Confirmar Exclusão</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    Tem certeza que deseja excluir a rodada <strong><?= htmlspecialchars($r['numero']) ?></strong>?
                    <input type="hidden" name="id" value="<?= $r['id'] ?>">
                </div>
                <div class="modal-footer">
                    <button type="submit" name="delete" class="btn btn-dark"><i class="bi bi-trash text-danger"></i> Excluir</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                </div>
            </form>
        </div>
    </div>
<?php endforeach; ?>

<?php include "../includes/footer.php"; ?>