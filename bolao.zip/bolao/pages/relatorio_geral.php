<?php
include "../includes/db.php";
include "../includes/header.php";

// Buscar participantes
$participantes = $pdo->query("SELECT * FROM participantes ORDER BY nome ASC")->fetchAll(PDO::FETCH_ASSOC);

// Buscar rodadas
$rodadas = $pdo->query("SELECT * FROM rodadas ORDER BY numero ASC")->fetchAll(PDO::FETCH_ASSOC);

// Rodada selecionada (padrão = primeira)
$rodadaSelecionada = $_GET['rodada'] ?? $rodadas[0]['id'];

// Buscar jogos da rodada
$jogosStmt = $pdo->prepare("SELECT j.*, r.numero AS rodada
                            FROM jogos j
                            JOIN rodadas r ON j.rodada_id = r.id
                            WHERE r.id = ?
                            ORDER BY j.data ASC");
$jogosStmt->execute([$rodadaSelecionada]);
$jogos = $jogosStmt->fetchAll(PDO::FETCH_ASSOC);

// Buscar palpites
$palpites = [];
$stmt = $pdo->query("SELECT * FROM palpites");
foreach ($stmt as $p) {
    $palpites[$p['participante_id']][$p['jogo_id']] = [
        'p1' => $p['palpite1'],
        'p2' => $p['palpite2']
    ];
}

// Função para ícone de acerto
function iconeAcerto($p1, $p2, $g1, $g2) {
    if ($g1 === null || $g2 === null) return "";
    if ($p1 == $g1 && $p2 == $g2) return "<span class='text-success fw-bold'>✅</span>";
    return "<span class='text-danger fw-bold'>❌</span>";
}

// Filtrar apenas participantes que têm palpites na rodada
$participantesComPalpite = array_filter($participantes, function($p) use ($jogos, $palpites) {
    foreach ($jogos as $j) {
        if (isset($palpites[$p['id']][$j['id']])) {
            return true;
        }
    }
    return false;
});
?>

<div class="container">

    <div class="card border-dark mb-4">
        <div class="card-header bg-black text-warning d-flex justify-content-between align-items-center">
            <span><i class="bi bi-bar-chart-line"></i> Relatório Geral – Palpites por Participante</span>
            <div>
                <button class="btn btn-success btn-sm" onclick="exportExcel()">Excel</button>
                <button class="btn btn-danger btn-sm" onclick="exportPDF()">PDF</button>
                <button class="btn btn-primary btn-sm" onclick="exportImage()">Imagem</button>
            </div>
        </div>
    </div>

    <!-- Seleção de rodada -->
    <form method="GET" class="mb-3">
        <label class="form-label">Selecione a Rodada:</label>
        <select name="rodada" class="form-select" onchange="this.form.submit()">
            <?php foreach ($rodadas as $r): ?>
                <option value="<?= $r['id'] ?>" <?= ($rodadaSelecionada == $r['id'] ? 'selected' : '') ?>>
                    Rodada <?= htmlspecialchars($r['numero']) ?> (limite <?= htmlspecialchars($r['data_limite']) ?>)
                </option>
            <?php endforeach; ?>
        </select>
    </form>

    <!-- Container para exportação -->
    <div id="rodadaContainer" class="row">
        <?php foreach ($participantesComPalpite as $p): ?>
            <div class="col-md-4 mb-4">
                <div class="card border-dark h-100">
                    <div class="card-header bg-black text-warning text-center">
                        <i class="bi bi-person-fill"></i> <?= htmlspecialchars($p['nome']) ?>
                    </div>
                    <div class="card-body table-responsive" style="max-height: 600px; overflow-y: auto;">
                        <table class="table table-bordered table-striped table-hover small">
                            <thead class="table-dark">
                                <tr>
                                    <th>Jogo</th>
                                    <th>Palpite</th>
                                    <th>Res.</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($jogos as $j): 
                                    $palpite = $palpites[$p['id']][$j['id']] ?? null;
                                ?>
                                    <tr>
                                        <td>
                                            <?= escudo($j['time1']) ?> <?= $j['time1'] ?><br>
                                            <?= escudo($j['time2']) ?> <?= $j['time2'] ?><br>
                                            <small class="text-muted">Rodada <?= $j['rodada'] ?></small>
                                        </td>
                                        <td class="text-center">
                                            <?php if ($palpite): ?>
                                                <strong><?= $palpite['p1'] ?> x <?= $palpite['p2'] ?></strong><br>
                                                <?= iconeAcerto($palpite['p1'], $palpite['p2'], $j['gol1'], $j['gol2']) ?>
                                            <?php else: ?>
                                                <span class="text-muted">–</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <?= ($j['gol1'] !== null)
                                                ? "<strong>{$j['gol1']} x {$j['gol2']}</strong>"
                                                : "-" ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

</div>

<!-- Exportação -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>

<script>
function exportExcel() {
    const tables = document.querySelectorAll("#rodadaContainer table");
    const wb = XLSX.utils.book_new();

    tables.forEach((table, i) => {
        const ws = XLSX.utils.table_to_sheet(table);
        XLSX.utils.book_append_sheet(wb, ws, "Participante_" + (i + 1));
    });

    XLSX.writeFile(wb, "palpites_rodada.xlsx");
}

function exportPDF() {
    const { jsPDF } = window.jspdf;
    html2canvas(document.querySelector("#rodadaContainer")).then(canvas => {
        const imgData = canvas.toDataURL("image/png");
        const pdf = new jsPDF("p", "mm", "a4");
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
        pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
        pdf.save("palpites_rodada.pdf");
    });
}

function exportImage() {
    html2canvas(document.querySelector("#rodadaContainer")).then(canvas => {
        const link = document.createElement("a");
        link.download = "palpites_rodada.png";
        link.href = canvas.toDataURL();
        link.click();
    });
}
</script>

<?php include "../includes/footer.php"; ?>