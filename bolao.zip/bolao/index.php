<?php
require_once __DIR__ . '/includes/config.php';
include __DIR__ . "/includes/header.php";
?>

<div class="container mt-4">
    <div class="card border-dark mb-4">
        <div class="card-header bg-black text-warning">
            <i class="bi bi-house-door-fill"></i> Dashboard do Bolão
        </div>
        <div class="card-body">
            <p class="lead">Bem-vindo ao <strong>Bolão do Galo ⚫⚪</strong>!</p>
            <p>Use o menu lateral para navegar entre as seções ou clique nos atalhos abaixo:</p>
        </div>
    </div>

    <div class="row">
        <!-- Participantes -->
        <div class="col-md-3 mb-3">
            <a href="<?= APP_URL ?>/pages/participantes.php" class="text-decoration-none">
                <div class="card text-center border-dark h-100">
                    <div class="card-body">
                        <i class="bi bi-people-fill display-4 text-warning"></i>
                        <h5 class="mt-2">Participantes</h5>
                    </div>
                </div>
            </a>
        </div>

        <!-- Rodadas -->
        <div class="col-md-3 mb-3">
            <a href="<?= APP_URL ?>/pages/rodadas.php" class="text-decoration-none">
                <div class="card text-center border-dark h-100">
                    <div class="card-body">
                        <i class="bi bi-calendar-event display-4 text-warning"></i>
                        <h5 class="mt-2">Rodadas</h5>
                    </div>
                </div>
            </a>
        </div>

        <!-- Jogos -->
        <div class="col-md-3 mb-3">
            <a href="<?= APP_URL ?>/pages/jogos.php" class="text-decoration-none">
                <div class="card text-center border-dark h-100">
                    <div class="card-body">
                        <i class="bi bi-controller display-4 text-warning"></i>
                        <h5 class="mt-2">Jogos</h5>
                    </div>
                </div>
            </a>
        </div>

        <!-- Palpites -->
        <div class="col-md-3 mb-3">
            <a href="<?= APP_URL ?>/pages/palpites.php" class="text-decoration-none">
                <div class="card text-center border-dark h-100">
                    <div class="card-body">
                        <i class="bi bi-pencil-square display-4 text-warning"></i>
                        <h5 class="mt-2">Palpites</h5>
                    </div>
                </div>
            </a>
        </div>

        <!-- Resultados -->
        <div class="col-md-3 mb-3">
            <a href="<?= APP_URL ?>/pages/resultados.php" class="text-decoration-none">
                <div class="card text-center border-dark h-100">
                    <div class="card-body">
                        <i class="bi bi-flag display-4 text-warning"></i>
                        <h5 class="mt-2">Resultados</h5>
                    </div>
                </div>
            </a>
        </div>

        <!-- Classificação -->
        <div class="col-md-3 mb-3">
            <a href="<?= APP_URL ?>/pages/classificacao.php" class="text-decoration-none">
                <div class="card text-center border-dark h-100">
                    <div class="card-body">
                        <i class="bi bi-trophy-fill display-4 text-warning"></i>
                        <h5 class="mt-2">Classificação</h5>
                    </div>
                </div>
            </a>
        </div>

        <!-- Relatório Participante -->
        <div class="col-md-3 mb-3">
            <a href="<?= APP_URL ?>/pages/relatorio_participante.php" class="text-decoration-none">
                <div class="card text-center border-dark h-100">
                    <div class="card-body">
                        <i class="bi bi-person-lines-fill display-4 text-warning"></i>
                        <h5 class="mt-2">Relatório Participante</h5>
                    </div>
                </div>
            </a>
        </div>

        <!-- Relatório Geral -->
        <div class="col-md-3 mb-3">
            <a href="<?= APP_URL ?>/pages/relatorio_geral.php" class="text-decoration-none">
                <div class="card text-center border-dark h-100">
                    <div class="card-body">
                        <i class="bi bi-bar-chart-line display-4 text-warning"></i>
                        <h5 class="mt-2">Relatório Geral</h5>
                    </div>
                </div>
            </a>
        </div>
    </div>
</div>

<?php
include __DIR__ . "/includes/footer.php";
?>