<?php
include "../includes/db.php";

$rodada_id = $_GET['rodada_id'] ?? "";

// Cabeçalho do CSV
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=palpites.csv');

$output = fopen("php://output", "w");

// Buscar participantes
$participantes = $pdo->query("SELECT * FROM participantes ORDER BY nome ASC")->fetchAll(PDO::FETCH_ASSOC);

// Cabeçalho da tabela
$header = ["Rodada", "Jogo", "Data", "Resultado"];
foreach ($participantes as $p) {
    $header[] = $p['nome'];
}
fputcsv($output, $header);

// Buscar jogos
if ($rodada_id) {
    $stmt = $pdo->prepare("SELECT j.*, r.numero AS rodada 
                           FROM jogos j 
                           JOIN rodadas r ON j.rodada_id = r.id 
                           WHERE j.rodada_id = ?
                           ORDER BY j.data ASC");
    $stmt->execute([$rodada_id]);
    $jogos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    $jogos = $pdo->query("SELECT j.*, r.numero AS rodada 
                          FROM jogos j 
                          JOIN rodadas r ON j.rodada_id = r.id 
                          ORDER BY r.numero ASC, j.data ASC")->fetchAll(PDO::FETCH_ASSOC);
}

// Buscar palpites
$palpites = [];
$stmt = $pdo->query("SELECT * FROM palpites");
foreach ($stmt as $p) {
    $palpites[$p['jogo_id']][$p['participante_id']] = "{$p['palpite1']} x {$p['palpite2']}";
}

// Montar linhas
foreach ($jogos as $j) {
    $linha = [
        "Rodada {$j['rodada']}",
        "{$j['time1']} x {$j['time2']}",
        date('d/m/Y H:i', strtotime($j['data'])),
        ($j['gol1'] !== null ? "{$j['gol1']} x {$j['gol2']}" : "-")
    ];

    foreach ($participantes as $p) {
        $linha[] = $palpites[$j['id']][$p['id']] ?? "-";
    }

    fputcsv($output, $linha);
}

fclose($output);
exit;

